local string = "Lua: Mode d'emploi."
local long = #string
print(long)   --> 19